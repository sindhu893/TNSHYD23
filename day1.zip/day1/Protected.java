package tns.day1;

public class Protected {
	int a=20;
	int b=30;
	protected void main()
	{
System.out.println("protected program");

	}

}
