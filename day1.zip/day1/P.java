package tns.day1;

public class P {
		//private
		private void display()
		{
			System.out.println("private program");
		}

		public static void main(String[] args) {
			P p1=new P();
			p1.display();
			 }
	}
	
