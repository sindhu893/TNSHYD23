package tns.day1;

public class Default {
	void display()
	{
		System.out.println("default program");

	}
	public class Default1{
		}

	public static void main(String[] args) {
	Default Default =new Default();
	Default.display();
		// TODO Auto-generated method stub

	}

}
