package tns.day1;

public class Approach2 {
	int b=10;
	static int a=20;
}
class sindhu{

public static void main(String[] args) {
	int c=30;
		System.out.println(c);
		Approach2 b1=new Approach2();
		System.out.println(b1.b);
		System.out.println(Approach2.a);
	
		// TODO Auto-generated method stub

	}

}
