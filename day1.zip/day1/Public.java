package tns.day1;

public class Public {
	public void display()
	{
		System.out.println("public progarm");
	}


	public static void main(String[] args) {
	Public p=new Public();
	p.display();
		// TODO Auto-generated method stub

	}

}
