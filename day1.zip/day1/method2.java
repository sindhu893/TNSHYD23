package tns.day1;

public class method2 {
	int a=30;
	static int b=20;
	int display() {
		return 0;
		
	}
	static void display1() {
		System.out.println();
		
		}
 public class method3
 {

	public static void main(String[] args) {
	int c=20;
	System.out.println(c);
	method2 method2=new method2();
	System.out. println(method2.a);
	method2.display();
	System.out.println(method2);
	method2.display();
	}
	
	
	
	
	// TODO Auto-generated method stub

	}

}
