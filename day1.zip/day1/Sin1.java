package tns.day1;

public class Sin1 {

	public static void main(String[] args) {
	System.out.println("Hello World");	// TODO Auto-generated method stub

	}

}
