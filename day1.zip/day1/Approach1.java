package tns.day1;

public class Approach1 {
	int b=10;
	static  int a=32;
	
	

	public static void main(String[] args) {
		int c=5;
		System.out.println(c);
		Approach1 b1=new Approach1();
		System.out.println(b1.b);
		System.out.println(Approach1.a);
		// TODO Auto-generated method stub

	}

}
